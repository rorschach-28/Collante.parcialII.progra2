package main;

import Model.LibroDeRecetas;
import Model.Receta;
import Model.TipoReceta;
import java.io.IOException;

public class main {

    public static void main(String[] args) {
        try {
// Crear un libro de recetas
            LibroDeRecetas<Receta> libro = new LibroDeRecetas<>();
            libro.agregar(new Receta(1, "Tarta de Verdura", "Abuela Rosa",
                    TipoReceta.VEGETARIANA));
            libro.agregar(new Receta(2, "Pollo al horno", "Juan Pérez",
                    TipoReceta.PLATO_PRINCIPAL));
            libro.agregar(new Receta(3, "Ensalada César", "Laura Ruiz", TipoReceta.ENTRADA));
            libro.agregar(new Receta(4, "Brownie", "Chef Martín", TipoReceta.POSTRE));
            libro.agregar(new Receta(5, "Pan sin gluten", "Lucía Gómez", TipoReceta.SIN_TACC));

// Mostrar todas las recetas
            System.out.println("Libro de recetas:");
            libro.paraCadaElemento(p -> System.out.println(p));

// Filtrar recetas por tipo Entrada
            System.out.println("\nRecetas Entrada:");
            libro.filtrar(p -> p.esTipo(TipoReceta.ENTRADA))
                    .forEach(System.out::println);

// Filtrar recetas cuyo nombre contiene "ensalada"
            System.out.println("\nRecetas que contienen 'tarta':");
            libro.filtrar(p -> {
                return p.getNombre().toLowerCase().contains("tarta");
            }).forEach(System.out::println);

// Ordenar recetas por ID (orden natural)
            System.out.println("\nRecetas ordenadas por ID:");
            libro.ordenar();
            libro.paraCadaElemento(System.out::println);

// Ordenar recetas por nombre
            System.out.println("\nRecetas ordenadas por nombre:");
            libro.ordenar((r1, r2) -> r1.getNombre().compareTo(r2.getNombre()));

// Guardar el libro en archivo binario
            libro.guardarEnArchivo("src/data/recetas.dat");

// Cargar el libro desde archivo binario
            LibroDeRecetas<Receta> libroCargado = new LibroDeRecetas<>();
            libroCargado.cargarDesdeArchivo("src/data/recetas.dat");

            System.out.println("\nRecetas cargadas desde archivo binario:");
            libroCargado.paraCadaElemento(System.out::println);

// Guardar el libro en archivo CSV
            libro.guardarEnCSV("src/data/recetas.csv");

// Cargar el libro desde archivo CSV
            libroCargado.cargarDesdeCSV("src/data/recetas.csv", e -> Receta.fromCSV(e));

            System.out.println("\nRecetas cargadas desde archivo CSV:");
            libroCargado.paraCadaElemento(System.out::println);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
