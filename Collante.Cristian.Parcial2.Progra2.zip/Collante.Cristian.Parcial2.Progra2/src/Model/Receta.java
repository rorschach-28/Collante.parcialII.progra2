package Model;

import repository.CSVSerializable;
import java.io.Serializable;
import java.util.Objects;

public class Receta implements Comparable<Receta>, CSVSerializable, Serializable {

    private static final long serialVersionUID = 1L;
    private final int id;
    private final String nombre;
    private final String autor;
    private final TipoReceta tipo;

    public Receta(int id, String nombre, String autor, TipoReceta tipo) {
        this.id = id;
        this.nombre = nombre;
        this.autor = autor;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }

    public TipoReceta getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return "Receta{" + "id=" + id + ", nombre=" + nombre + ", autor=" + autor + ", tipo=" + tipo + '}';
    }

    @Override
    public int compareTo(Receta r) {
        return Integer.compare(this.id, r.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + autor + "," + tipo;
    }

    public static String toCSV(String id, String nombre, String autor, String tipo) {
        return id + "," + nombre + "," + autor + "," + tipo;
    }

    public static Receta fromCSV(String recetaCSV) {
        Receta toReturn = null;
        if (recetaCSV.endsWith("\n")) {
            recetaCSV = recetaCSV.substring(0, recetaCSV.length() - 1);
        }

        String[] values = recetaCSV.split(",");
        if (values.length == 4) {
            int id = Integer.parseInt(values[0]);
            String nombre = values[1];
            String autor = values[2];
            TipoReceta tipo = TipoReceta.valueOf(values[3]);

            toReturn = new Receta(id, nombre, autor, tipo);
        }

        return toReturn;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Receta r)) {
            return false;
        }
        return r.id == id;

    }

    public boolean esTipo(TipoReceta tipo) {
        return this.tipo == tipo;

    }
}
