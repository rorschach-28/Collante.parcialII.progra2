package Model;

import repository.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class LibroDeRecetas<T extends CSVSerializable> implements Serializable {

    private List<T> recetas;

    public LibroDeRecetas() {
        this.recetas = new ArrayList<>();
    }

    public void agregar(T elem) {
        checkItem(elem);
        contiene(recetas, elem);
        recetas.add(elem);
    }

    public T obtener(int indice) {
        chequearIndex(indice);
        return recetas.get(indice);
    }

    public void eliminar(int indice) {
        chequearIndex(indice);
        recetas.remove(indice);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        chequearCriterio(criterio);
        List<T> toReturn = new ArrayList<>();
        for (T elem : recetas) {
            if (criterio.test(elem)) {
                toReturn.add(elem);
            }
        }
        return toReturn;
    }

    public void ordenar(Comparator<? super T> comparador) {
        recetas.sort(comparador);
    }

    public void ordenar() {
        if (!recetas.isEmpty() && obtener(0) instanceof Comparable) {
            recetas.sort((Comparator<? super T>) Comparator.naturalOrder());
            return;
        }
        throw new IllegalStateException("Los elementos almacendos no se pueden ordenar en orden natural");
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        if (accion == null) {
            throw new NullPointerException("Accion nula");
        }
        for (T elem : recetas) {
            accion.accept(elem);
        }
    }

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            sinRecetas();
            salida.writeObject(recetas);
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(path))) {
            recetas = (List<T>) in.readObject();
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            sinRecetas();
            for (T elem : recetas) {
                writer.write(elem.toCSV() + "\n");
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> constructor) throws IOException {
        try (BufferedReader bfReader = new BufferedReader(new FileReader(path))) {
            recetas.clear();
            String linea;
            while ((linea = bfReader.readLine()) != null) {
                agregar(constructor.apply(linea));
            }
        }

    }

    private void chequearIndex(int indice) {
        if (indice < 0 || indice >= recetas.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    private void checkItem(T item) {
        chequearNull(item);
        contiene(recetas, item);
    }

    private void chequearCriterio(Predicate<? super T> criterio) {
        if (criterio == null) {
            throw new NullPointerException("Criterio vaqcio");
        }
    }

    private void contiene(List<T> lista, T elemento) {
        if (lista.contains(elemento)) {
            throw new IllegalStateException("El elemento ya existe en el libro");
        }
    }

    private void chequearNull(T item) {
        if (item == null) {
            throw new NullPointerException("ERROR:elemento nulo");
        }
    }

    private void sinRecetas() {
        if (recetas.isEmpty()) {
            throw new IllegalStateException("El libro esta vacio ");
        }
    }

}
