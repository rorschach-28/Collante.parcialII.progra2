package repository;

public interface CSVSerializable {

    String toCSV();


}

